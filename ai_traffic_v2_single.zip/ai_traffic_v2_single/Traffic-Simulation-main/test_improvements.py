#!/usr/bin/env python3
"""
Test script for the improved traffic simulation with:
1. Better collision detection
2. Fixed timing display
3. Speed control
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from trafficSim import *

def test_collision_detection():
    """Test that vehicles don't overlap when following each other"""
    print("Testing collision detection...")
    
    # Create a simple simulation with one road
    sim = Simulation()
    road = sim.create_road((0, 0), (100, 0))
    
    # Create two vehicles on the same road
    vehicle1 = Vehicle({'l': 5, 'v_max': 10})
    vehicle1.x = 20
    vehicle2 = Vehicle({'l': 5, 'v_max': 10}) 
    vehicle2.x = 10
    
    road.vehicles.extend([vehicle1, vehicle2])
    
    # Update several times and check for collisions
    for _ in range(50):
        road.update(1/60)
        if len(road.vehicles) >= 2:
            v1, v2 = road.vehicles[0], road.vehicles[1]
            distance = v1.x - v2.x - v2.l
            if distance < 0:
                print(f"❌ Collision detected: distance = {distance}")
                return False
    
    print("✅ Collision detection working")
    return True

def test_speed_control():
    """Test simulation speed control"""
    print("Testing speed control...")
    
    sim = Simulation()
    
    # Test speed multiplier
    sim.set_speed(2.0)
    assert abs(sim.speed_multiplier - 2.0) < 0.001, "Speed setting failed"
    
    sim.speed_up()
    assert sim.speed_multiplier > 2.0, "Speed up failed"
    
    sim.slow_down()
    sim.slow_down()
    assert sim.speed_multiplier < 2.0, "Slow down failed"
    
    # Test bounds
    sim.set_speed(100)  # Should clamp to max
    assert sim.speed_multiplier <= 10.0, "Speed clamping failed"
    
    sim.set_speed(0.01)  # Should clamp to min
    assert sim.speed_multiplier >= 0.1, "Speed minimum clamping failed"
    
    print("✅ Speed control working")
    return True

def test_prolog_agent_fallback():
    """Test that simulation falls back gracefully if Prolog isn't available"""
    print("Testing Prolog agent fallback...")
    
    try:
        sim = Simulation()
        roads = [
            [sim.create_road((0, 0), (50, 0))],
            [sim.create_road((0, 0), (0, 50))],
            [sim.create_road((50, 0), (0, 0))],
            [sim.create_road((0, 50), (0, 0))]
        ]
        
        # Create signal - should work with or without Prolog
        signal = sim.create_signal([[0], [1], [2], [3]])
        
        # Update should work
        signal.update(sim)
        
        print("✅ Traffic signal working (with or without Prolog)")
        return True
        
    except Exception as e:
        print(f"❌ Traffic signal failed: {e}")
        return False

def main():
    print("🚦 Testing Traffic Simulation Improvements")
    print("=" * 50)
    
    tests = [
        test_collision_detection,
        test_speed_control, 
        test_prolog_agent_fallback
    ]
    
    passed = 0
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"❌ Test {test.__name__} failed with error: {e}")
    
    print(f"\n📊 Results: {passed}/{len(tests)} tests passed")
    
    if passed == len(tests):
        print("🎉 All improvements working correctly!")
        print("\nKeyboard controls in simulation:")
        print("  +/-  : Speed up/slow down")
        print("  R    : Reset speed to normal")
        print("  Space: Pause/resume")
    else:
        print("⚠️  Some tests failed - check implementation")

if __name__ == "__main__":
    main()