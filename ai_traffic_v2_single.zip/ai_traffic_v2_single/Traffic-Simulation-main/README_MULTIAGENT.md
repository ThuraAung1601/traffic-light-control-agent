# Multi-Agent Prolog Traffic Control System

## Overview

This project implements an intelligent traffic light control system using a multi-agent approach with Prolog rules. Each intersection is controlled by an autonomous agent that makes decisions based on real-time traffic conditions using logical rules written in Prolog.

## System Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Simulation    │────│ Traffic Signal  │────│ Prolog Agent    │
│   (main.py)     │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│     Roads       │    │     Vehicles    │    │ Prolog Rules    │
│     (road.py)   │    │  (vehicle.py)   │    │  (rules.pl)     │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## How the Multi-Agent System Works

### 1. Agent Architecture

Each intersection has its own **PrologTrafficAgent** that acts autonomously:

```python
# From trafficSim/prolog_agent.py
class PrologTrafficAgent:
    def __init__(self, name: str, rules_path: Optional[str] = None):
        if Prolog is None:
            raise RuntimeError("pyswipl/SWI-Prolog not available")
        self.name = name
        self.prolog = Prolog()
        self.rules_path = rules_path or RULES_PATH_DEFAULT
        self.prolog.consult(self.rules_path)  # Load Prolog rules
        self.set_current_state(1, pattern_duration=240, greentime=0)
```

### 2. Agent Decision Making Process

Each agent follows this decision loop every simulation frame:

```python
# From trafficSim/traffic_signal.py - update method
def update(self, sim):
    if self.control == 'prolog' and len(self.roads) >= 4 and self._prolog_agent is not None:
        # Step 1: Measure current traffic conditions
        queues = self._measure_queues()
        self._prolog_agent.update_queues(queues)
        
        # Step 2: Check if early pattern change is needed
        change_early = self._prolog_agent.should_change_early(self._pattern)
        
        # Step 3: Make decision
        if self._frames_left <= 0 or change_early:
            # Ask Prolog agent to decide next pattern
            next_p = self._prolog_agent.decide_next_pattern()
            self._pattern = int(next_p)
            self._apply_pattern(self._pattern)  # Apply to traffic lights
```

### 3. Traffic Monitoring

Each agent continuously monitors traffic conditions:

```python
# From trafficSim/traffic_signal.py
def _measure_queues(self) -> Dict[str, int]:
    # mapping groups -> directions (based on main.py create_signal order)
    # 0: west inbound, 1: south inbound, 2: east inbound, 3: north inbound
    dir_map = {0: 'west', 1: 'south', 2: 'east', 3: 'north'}
    q: Dict[str, int] = {"north": 0, "south": 0, "east": 0, "west": 0}
    for gi, group in enumerate(self.roads[:4]):
        dname = dir_map.get(gi)
        if not dname:
            continue
        total = 0
        for rd in group:
            total += len(rd.vehicles)  # Count vehicles in queue
        q[dname] = total
    return q
```

## Prolog Rules System

### 1. Pattern Definitions

The system uses 12 traffic light patterns that serve different combinations of directions:

```prolog
% From rules.pl - Pattern definitions
% Which directions are served (any movement) by a pattern
serves_dirs(1,  [north, south]).        % N/S straight
serves_dirs(2,  [east, west]).          % E/W straight
serves_dirs(3,  [north]).               % North straight/turns
serves_dirs(4,  [south]).
serves_dirs(5,  [east]).
serves_dirs(6,  [west]).
serves_dirs(7,  [north, east]).         % Combo (non-conflicting)
serves_dirs(8,  [north, west]).
serves_dirs(9,  [south, east]).
serves_dirs(10, [south, west]).
serves_dirs(11, [north, south]).        % All N/S
serves_dirs(12, [east, west]).          % All E/W
```

### 2. Intelligent Pattern Selection

The core decision-making logic uses multiple strategies:

```prolog
% From rules.pl - Main pattern selection
select_next_pattern(CurrentPattern, QN, QS, QE, QW, TN, TS, TE, TW, NextPattern) :-
    TotalNS is QN + QS,
    TotalEW is QE + QW,
    TotalAll is TotalNS + TotalEW,

    % Strategy 1: High turn demand
    ( select_turn_pattern(QN, RN, north, NextPattern) -> true
    ; select_turn_pattern(QS, RS, south, NextPattern) -> true
    ; select_turn_pattern(QE, RE, east,  NextPattern) -> true
    ; select_turn_pattern(QW, RW, west,  NextPattern) -> true
    
    % Strategy 2: Balanced perpendicular traffic
    ; (TotalAll > 8, abs(TotalNS - TotalEW) < 8) ->
        select_combination_pattern(QN, QS, QE, QW, NextPattern)
    
    % Strategy 3: High demand in one axis
    ; TotalNS > TotalEW * 1.5, TotalNS > 10 -> NextPattern = 11  % Full N-S
    ; TotalEW > TotalNS * 1.5, TotalEW > 10 -> NextPattern = 12  % Full E-W
    
    % Strategy 4: Default to stronger axis
    ; TotalNS > TotalEW -> NextPattern = 1  % N-S straight
    ; TotalEW > TotalNS -> NextPattern = 2  % E-W straight
    
    % Strategy 5: Round-robin fallback
    ; cycle_pattern(CurrentPattern, NextPattern)
    ).
```

### 3. Early Pattern Change Rules

Agents can change patterns early if conditions warrant:

```prolog
% From rules.pl - Early change decision
should_change_early(Pattern) :-
    serves_dirs(Pattern, Dirs),
    forall(member(D, Dirs), (queue_for_direction(D, Q), Q =:= 0)).
```

This rule fires when all directions served by the current pattern have zero queue length.

## Python-Prolog Integration

### 1. Querying Prolog from Python

The Python agent wrapper communicates with Prolog:

```python
# From trafficSim/prolog_agent.py
def decide_next_pattern(self) -> int:
    pat = list(self.prolog.query("current_state(P)"))[0]["P"]
    res = list(self.prolog.query(f"decide_next_pattern({pat},NP)"))
    return int(res[0]["NP"]) if res else int(pat)

def should_change_early(self, pattern: Optional[int] = None) -> bool:
    pat = pattern if pattern is not None else list(self.prolog.query("current_state(P)"))[0]["P"]
    return bool(list(self.prolog.query(f"should_change_early({int(pat)})")))
```

### 2. Updating Traffic State

Real-time traffic data is fed to Prolog:

```python
# From trafficSim/prolog_agent.py
def update_queues(self, queues: Dict[str, int]):
    for d in ("north", "south", "east", "west"):
        self._retractall(f"queue_length({d},_)")
        q = int(queues.get(d, 0))
        self.prolog.assertz(f"queue_length({d},{q})")
```

## Multi-Agent Coordination

### 1. Supervisor Agent

A supervisor agent monitors multiple intersections for deadlock detection:

```python
# From trafficSim/prolog_agent.py
class SupervisorAgent:
    def post_junction_state(self, junction_id: str, pattern: int, occupancy: float,
                            counter: int = 0, greentime: int = 0, now: int = 0):
        self.prolog.assertz(
            f"working_memory(junction_state({junction_id},{int(pattern)},{int(counter)},{int(greentime)},{int(now)}))"
        )
        self.prolog.assertz(
            f"working_memory(junction_occupancy({junction_id},{float(occupancy)}))"
        )

    def recommend(self) -> Optional[Tuple[str,int]]:
        res = list(self.prolog.query("supervisor_recommendation(J,NP)"))
        if res:
            return str(res[0]["J"]), int(res[0]["NP"])
        return None
```

### 2. Deadlock Detection Logic

```prolog
% From rules.pl - Supervisor deadlock detection
supervisor_recommendation(WeakestJunction, NewPattern) :-
    all_current_full_flows(Flow_List),
    possible_loops(Flow_List, _),
    findall([J,Occ],
            (member([J,_,Occ], Flow_List)),
            Pairs),
    weakest_junction(Pairs, WeakestJunction, _),
    working_memory(junction_state(WeakestJunction, OldPattern, _, _, _)),
    select_alternative_pattern(WeakestJunction, OldPattern, NewPattern).
```

## Vehicle Behavior and Collision Prevention

### 1. Improved Car-Following Model

Enhanced vehicle update logic prevents collisions:

```python
# From trafficSim/vehicle.py
def update(self, lead, dt):
    # ... position/velocity updates ...
    
    if lead:
        delta_x = lead.x - self.x - lead.l
        delta_v = self.v - lead.v

        # Collision prevention: ensure minimum safe distance
        min_safe_distance = self.s0 + 1.0  # Add extra safety margin
        if delta_x < min_safe_distance:
            # Emergency braking to prevent collision
            self.a = -self.b_max
            if delta_x <= self.l * 0.1:  # Very close collision
                self.v = max(0, self.v * 0.5)  # Hard brake
        else:
            # Normal IDM car-following model with safety check
            alpha = (self.s0 + max(0, self.T*self.v + delta_v*self.v/self.sqrt_ab)) / max(delta_x, 0.1)
```

### 2. Traffic Signal Response

Vehicles respond to traffic signals dynamically:

```python
# From trafficSim/road.py
def update(self, dt):
    # ... update vehicles ...
    
    # Check for traffic signal
    if self.traffic_signal_state:
        # Green light - let vehicles pass
        self.vehicles[0].unstop()
        for vehicle in self.vehicles:
            vehicle.unslow()
    else:
        # Red light - slow and stop vehicles
        if self.vehicles[0].x >= self.length - self.traffic_signal.slow_distance:
            self.vehicles[0].slow(self.traffic_signal.slow_factor*self.vehicles[0]._v_max)
        if self.vehicles[0].x >= self.length - self.traffic_signal.stop_distance:
            self.vehicles[0].stop()
```

## Simulation Control Features

### 1. Speed Control

Users can control simulation speed in real-time:

```python
# From trafficSim/simulation.py
def set_speed(self, multiplier):
    """Set simulation speed multiplier. 1.0 = normal, 0.5 = half speed, 2.0 = double speed"""
    self.speed_multiplier = max(0.1, min(10.0, multiplier))  # Clamp between 0.1x and 10x

def update(self):
    # Apply speed multiplier to effective dt
    effective_dt = self.dt * self.speed_multiplier
    
    # Update every road
    for road in self.roads:
        road.update(effective_dt)
```

### 2. Keyboard Controls

Interactive controls are handled in the window:

```python
# From trafficSim/window.py
elif event.type == pygame.KEYDOWN:
    if event.key == pygame.K_PLUS or event.key == pygame.K_EQUALS:
        # Speed up simulation
        self.sim.speed_up()
        print(f"Speed: {self.sim.speed_multiplier:.1f}x")
    elif event.key == pygame.K_MINUS:
        # Slow down simulation
        self.sim.slow_down()
        print(f"Speed: {self.sim.speed_multiplier:.1f}x")
    elif event.key == pygame.K_SPACE:
        # Pause/resume simulation
        if self.sim.isPaused:
            self.sim.resume()
        else:
            self.sim.pause()
```

## Configuration and Setup

### 1. Main Simulation Setup

The main simulation creates the intersection layout:

```python
# From main.py
# Create signals for intersections
sim.create_signal([[0], [1], [2], [3]])      # Main 4-way intersection
sim.create_signal([[12], [13], [14], [15]])  # Secondary 4-way intersection

# Create always-green signals for through lanes
sim.create_signal([[24]])  # Always green for dedicated lanes
sim.create_signal([[25]])
sim.create_signal([[26]])
sim.create_signal([[27]])
```

### 2. Fallback Mechanism

The system gracefully falls back to rule-based control if Prolog is unavailable:

```python
# From trafficSim/traffic_signal.py
def _init_control_mode(self):
    # Only meaningful for 4-group signals
    if self.control == 'prolog' and _PROLOG_AVAILABLE and len(self.roads) >= 4:
        try:
            self._prolog_agent = PrologTrafficAgent("junction")
            # ... initialize prolog agent ...
        except Exception:
            # fallback to rule mode if prolog fails
            self.control = 'rule'
```

## Benefits of This Approach

1. **Intelligent Decision Making**: Agents make decisions based on real traffic conditions rather than fixed timing
2. **Adaptability**: Rules can be easily modified without changing code
3. **Coordination**: Multiple agents can coordinate to prevent deadlocks
4. **Extensibility**: New rules and behaviors can be added in Prolog
5. **Robustness**: Graceful fallback to simpler control if Prolog is unavailable

## Usage

1. **Install Requirements**: `pip install -r requirements.txt`
2. **Install SWI-Prolog**: `brew install swi-prolog` (on macOS)
3. **Run Simulation**: `python main.py`
4. **Controls**:
   - `+/-`: Speed up/slow down
   - `R`: Reset speed to normal
   - `Space`: Pause/resume
   - Mouse: Pan and zoom

This multi-agent system demonstrates how logical reasoning (Prolog) can be combined with real-time simulation to create intelligent, adaptive traffic control systems.