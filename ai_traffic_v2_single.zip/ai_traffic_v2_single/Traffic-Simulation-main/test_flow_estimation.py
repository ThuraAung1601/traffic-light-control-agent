"""
Test script to verify flow estimation and pattern diversity.
Runs simulation and tracks which traffic patterns are selected over time.
"""
import numpy as np
from trafficSim import *
from collections import Counter
import sys

# Simulation parameters
STEPS = 3000  # Run for 3000 frames (~50 seconds at 60 FPS)
VEHICLE_RATE = 400  # Vehicles per minute

def main():
    print("=" * 70)
    print("FLOW ESTIMATION & PATTERN DIVERSITY TEST")
    print("=" * 70)
    
    # Create simulation (copy setup from main.py)
    sim = Simulation()
    n = 20
    a = -2
    b = 12
    l = 300
    NUM_OF_ROADS = 36
    
    # Setup roads (abbreviated from main.py)
    WEST_RIGHT_START = (-b-l, a)
    WEST_LEFT_START = (-b-l, -a)
    SOUTH_RIGHT_START = (a, b+l)
    SOUTH_LEFT_START = (-a, b+l)
    EAST_RIGHT_START = (b+l, -a)
    EAST_LEFT_START = (b+l, a)
    NORTH_RIGHT_START = (-a, -b-l)
    NORTH_LEFT_START = (a, -b-l)
    
    WEST_RIGHT = (-b, a)
    WEST_LEFT = (-b, -a)
    SOUTH_RIGHT = (a, b)
    SOUTH_LEFT = (-a, b)
    EAST_RIGHT = (b, -a)
    EAST_LEFT = (b, a)
    NORTH_RIGHT = (-a, -b)
    NORTH_LEFT = (a, -b)
    
    # Create basic road network
    roads = [
        # Inbound
        Road(WEST_RIGHT_START, WEST_RIGHT),
        Road(SOUTH_RIGHT_START, SOUTH_RIGHT),
        Road(EAST_RIGHT_START, EAST_RIGHT),
        Road(NORTH_RIGHT_START, NORTH_RIGHT),
        # Outbound
        Road(WEST_LEFT, WEST_LEFT_START),
        Road(SOUTH_LEFT, SOUTH_LEFT_START),
        Road(EAST_LEFT, EAST_LEFT_START),
        Road(NORTH_LEFT, NORTH_LEFT_START),
        # Straight through
        Road(WEST_RIGHT, EAST_LEFT),
        Road(SOUTH_RIGHT, NORTH_LEFT),
        Road(EAST_RIGHT, WEST_LEFT),
        Road(NORTH_RIGHT, SOUTH_LEFT),
    ]
    
    # Add turn roads
    for i in range(NUM_OF_ROADS - 12):
        roads.append(Road((0, 0), (10, 10)))  # Placeholder turns
    
    sim.create_roads(roads)
    
    # Create traffic signal
    sim.create_signal([[0], [1], [2], [3]])
    
    # Get the signal
    signal = sim.traffic_signals[0]
    
    # Check if prolog is active
    if signal.control != 'prolog':
        print("⚠️  WARNING: Prolog control not active!")
        print(f"   Control mode: {signal.control}")
        print("   Make sure pyswip is installed: pip install pyswip")
        return
    
    print(f"✓ Prolog control active")
    print(f"✓ Control type: {signal.control}")
    print()
    
    # Create generators with diverse traffic patterns
    # Mix of straight-through and turning movements
    sim.create_gen({
        'vehicle_rate': VEHICLE_RATE,
        'vehicles': [
            # West approaches
            [3, {'path': [0, 8, 6]}],      # West straight
            [2, {'path': [0, 36, 7]}],     # West right turn (placeholder)
            [2, {'path': [0, 40, 5]}],     # West left turn (placeholder)
            # South approaches  
            [3, {'path': [1, 9, 7]}],      # South straight
            [2, {'path': [1, 44, 4]}],     # South right turn
            [2, {'path': [1, 48, 6]}],     # South left turn
            # East approaches
            [3, {'path': [2, 10, 4]}],     # East straight
            [2, {'path': [2, 52, 5]}],     # East right turn
            [2, {'path': [2, 56, 7]}],     # East left turn
            # North approaches
            [3, {'path': [3, 11, 5]}],     # North straight
            [2, {'path': [3, 60, 6]}],     # North right turn
            [2, {'path': [3, 64, 4]}],     # North left turn
        ]
    })
    
    # Track pattern usage
    pattern_history = []
    rule_history = []
    
    print("Running simulation...")
    print(f"Steps: {STEPS} frames")
    print()
    
    # Run simulation
    for step in range(STEPS):
        sim.run(1)
        
        # Record current pattern
        pattern_history.append(signal.current_pattern)
        
        # Record fired rules every 100 steps
        if step % 100 == 0 and signal.prolog_agent:
            fired_rules = signal.prolog_agent.get_fired_rules()
            if fired_rules:
                rule_history.extend([r[0] for r in fired_rules])
            
            # Progress indicator
            progress = (step / STEPS) * 100
            queues = signal._measure_queues()
            total_vehicles = sum(queues.values())
            print(f"  Step {step:4d} | Pattern: {signal.current_pattern:2d} | "
                  f"Vehicles: {total_vehicles:3d} | Progress: {progress:5.1f}%")
    
    print()
    print("=" * 70)
    print("RESULTS")
    print("=" * 70)
    
    # Analyze pattern diversity
    pattern_counts = Counter(pattern_history)
    print("\nPattern Usage Frequency:")
    print("-" * 40)
    for pattern in sorted(pattern_counts.keys()):
        count = pattern_counts[pattern]
        percentage = (count / len(pattern_history)) * 100
        bar = "█" * int(percentage / 2)
        print(f"  Pattern {pattern:2d}: {count:4d} times ({percentage:5.2f}%) {bar}")
    
    print(f"\nTotal unique patterns used: {len(pattern_counts)}")
    
    if len(pattern_counts) <= 2:
        print("\n⚠️  WARNING: Only patterns 1-2 used!")
        print("   Flow estimation may need tuning or traffic is too uniform.")
    elif len(pattern_counts) >= 6:
        print("\n✓ GOOD: Diverse pattern selection (6+ patterns)")
    else:
        print(f"\n✓ Moderate diversity: {len(pattern_counts)} patterns used")
    
    # Analyze rule firing
    if rule_history:
        rule_counts = Counter(rule_history)
        print("\n\nMost Frequently Fired Rules:")
        print("-" * 40)
        for rule, count in rule_counts.most_common(10):
            print(f"  Rule {rule}: {count} times")
    
    print("\n" + "=" * 70)
    print("Test complete!")
    print("=" * 70)

if __name__ == "__main__":
    main()
